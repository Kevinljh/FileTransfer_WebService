CIHI
OMHRS XML Schema for Submission version for Release 2011_1.0
Includes OMHRS XML Edit Specifications v2011_1.0

Contents
========

XML Submission Schema:
	SubmissionSpecifications\OMHRSSubmission.xsd
	SubmissionSpecifications\OMHRSRecordType.xsd
	SubmissionSpecifications\OMHRSElement.xsd
	SubmissionSpecifications\OMHRSElementType.xsd
	SubmissionSpecifications\OMHRSSimpleType.xsd

Submission Sample Files:
	SubmissionSpecifications\Sample\FacilityProfile.xml
	SubmissionSpecifications\Sample\AssessmentRecords.xml

Submission HTML Documentation:
	SubmissionSpecifications\Documentation\omhrsXMLSchema.html

XML Edit Specifications:
	EditSpecifications\Rule.xsd
	EditSpecifications\Rule.xml
	EditSpecifications\Error.xsd
	EditSpecifications\Error.xml


Documentation Legends
=====================
In the HTML documentation, optional elements or complex types are 
denoted by dotted outlines. A "sequence" complex type is represented by 
an octagon with 3 dots on a solid line, and a "choice" complex type is 
represented by an octagon with a switch symbol.

Version 2011_1.0
========================
The XML Submission Schema is compatible with the Flat File Submission 
specifications Release 2011_1.0
The XML Edit Specifications are compatible with the excel-based Edit
specifications Release 2011_1.0.

Version 2011_1.0 changes are noted below: 

Submission Specifications
=========================
OMHRSElement.xsd:
* Added element AxisIIDSMIVCodeE, AxisIIDSMIVCodeF, DateAdmittedToMentalHealthBed, MajorSkinProblems, OtherSkinConditions, FootProblems, ReasonForAdmissionForensicAssessment
* Removed element WaitTime, DateWaitBegan
* Changed element name: from AxisIIDSMIVCode to AxisIIDSMIVCodeD

OMHRSElementType.xsd:
* Added element type DSMType, FootProblemType, SkinProblemType 
* Modified values/description for element types  LanguageType, PastMedicationSideEffectsType,ReasonForAdmissionType, DateType
* Removed element type: WaitTimeType, SkinOrFootProblemType 

OMHRSRecordType.xsd:
* Added AdmissionAssessmentElementsType/DateAdmittedToMentalHealthBed , ReasonForAdmissionForensicAssessment , MajorSkinProblems, OtherSkinConditions, FootProblems, AxisIIDSMIVCodeE, AxisIIDSMIVCodeF 
* Added QuarterlyAssessmentElementsType/MajorSkinProblems, OtherSkinConditions, FootProblems, AxisIIDSMIVCodeE, AxisIIDSMIVCodeF
* Added ChangeInStatusAssessmentType/MajorSkinProblems, OtherSkinConditions, FootProblems, AxisIIDSMIVCodeE, AxisIIDSMIVCodeF
* Added DischargeAssessmentElementsType/MajorSkinProblems, OtherSkinConditions, FootProblems, AxisIIDSMIVCodeE, AxisIIDSMIVCodeF
* Added ShortStayAssessmentElementsType/DateAdmittedToMentalHealthBed , ReasonForAdmissionForensicAssessment , MajorSkinProblems, OtherSkinConditions, FootProblems, AxisIIDSMIVCodeE, AxisIIDSMIVCodeF 
* Removed AdmissionAssessmentElementsType/WaitTime, DateWaitBegan, SkinOrFootProblem
* Removed QuarterlyAssessmentElementsType/NumberOfPsychAdmitsRecent, NumberOfPsychAdmitsLifetime, TimeSinceLastDischarge, AmountOfTimeHospitalized, ContactWithCommunityMentalHealth, AgeAtFirstHospitalization
* Removed ChangeInStatusAssessmentType/NumberOfPsychAdmitsRecent, NumberOfPsychAdmitsLifetime, TimeSinceLastDischarge, AmountOfTimeHospitalized, ContactWithCommunityMentalHealth, AgeAtFirstHospitalization
* Removed DischargeAssessmentElementsType/NumberOfPsychAdmitsRecent, NumberOfPsychAdmitsLifetime, TimeSinceLastDischarge, AmountOfTimeHospitalized, ContactWithCommunityMentalHealth, AgeAtFirstHospitalization
* Removed ShortStayAssessmentElementsType/WaitTime, DateWaitBegan, SkinOrFootProblem
* Removed @minOccurs=0 from DischargeAssessmentElementsType/MakingSelfUnderstood
* Removed @minOccurs=0 from ShortStayAssessmentElementsType/MakingSelfUnderstood
* Changed AdmissionAssessmentElementsType refered element from AxisIIDSMIVCode to AxisIIDSMIVCodeD
* Changed QuarterlyAssessmentElementsType refered element from AxisIIDSMIVCode to AxisIIDSMIVCodeD
* Changed ChangeInStatusAssessmentType refered element from AxisIIDSMIVCode to AxisIIDSMIVCodeD
* Changed DischargeAssessmentElementsType refered element from  AxisIIDSMIVCode to AxisIIDSMIVCodeD
* Changed ShortStayAssessmentElementsType refered element from AxisIIDSMIVCode to AxisIIDSMIVCodeD

Edit Specifications
===================
Rule.xml:
* Replaced rules 00191 with 00192, 00291 with 00292, 00301 with 00302, 00700 with 02010, 00840 with 02020, 01640 with 01641, 01660 with 01661, 01700 with 01701,
  01750 with 01751, 01960 with 01961, 20006 with 20048, 20024 with 20046, 20037 with 20049, 20039 with 20051, 20043 with 20044 and 20045, 40000 with 40266,
  40261 with 40267, 40262 with 40268 
* Removed rules 01820
* Added rules 01990, 02000, 20047, 20050
* Added MajorSkinProblems, OtherSkinConditions, FootProblems to rule 40266.
* added AxisIIDSMIVCodeE, AxisIIDSMIVCodeF elements to rule  01890, 01900, 01910, 01920, 01930 .
* For rule 01641,01870, 01880, 01890, 01900, 01910, 01920, 01930, 40268 : change applied element from AxisIIDSMIVCode to AxisIIDSMIVCodeD.
* For rule 01591: change applied element from DischargeDate to ServiceInterruptionEndDateA, ServiceInterruptionEndDateB, ServiceInterruptionEndDateC
Error.xml:
* Replace error messages 000110 with 000111, 000400 with 000401, 000501 with 000502, 000850 with 000851,001460 with 001461, 001480 with 001481, 001510 with 001511, 001560 with 001561, 001610 with 001611, 001650 with 001651, 001820 with 001821
* Removed error messages 001680
* Added error messages 001850,001860,001870, 001880, 001890 
